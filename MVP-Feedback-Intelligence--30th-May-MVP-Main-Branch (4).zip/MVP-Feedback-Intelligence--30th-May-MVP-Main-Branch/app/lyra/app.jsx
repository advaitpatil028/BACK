/* Feedback Intelligence — main app router and shell glue. */

const FI_NAV = [
  { type: "group", icon: "campaigns", label: "Campaign Management", expanded: true, children: [
    { label: "Survey Campaigns", key: "campaigns" },
    { label: "Survey Templates", key: "designs", isNew: true },
  ]},
  { type: "leaf", icon: "topics", label: "VU Score Model", isNew: true, key: "ontology" },
];

const WFM_NAV = [
  { type: "leaf",  icon: "campaigns", label: "Schedule Manager" },
  { type: "leaf",  icon: "alerts",    label: "Real Time Adherence", active: true },
  { type: "leaf",  icon: "topics",    label: "Intraday Manager" },
  { type: "group", icon: "insights",  label: "Forecasting" },
  { type: "group", icon: "settings",  label: "Setup" },
];

function WFMPlaceholder({ onOpenSwitcher }) {
  return (
    <div className="pane">
      <div className="pane-head">
        <h1>Real Time Adherence</h1>
        <div className="head-actions">
          <button className="btn">Export</button>
        </div>
      </div>
      <div style={{ padding: "0 var(--space-6) var(--space-6)", color: "var(--lyra-slate-500)", font: "400 13px/var(--space-5) Inter" }}>
        <div style={{ background: "var(--lyra-white)", border: "1px dashed rgba(0,0,0,0.16)", borderRadius: 10, padding: 32, textAlign: "center" }}>
          <div style={{ font: "500 16px/24px Inter", color: "var(--lyra-slate-900)", marginBottom: 6 }}>
            Workforce Management
          </div>
          <p style={{ maxWidth: 520, margin: "0 auto var(--space-4)" }}>
            This is the existing WFM surface. Open the app switcher to jump into
            <strong style={{ color: "var(--lyra-slate-900)" }}> Feedback Intelligence</strong> —
            it lives under Workforce Engagement and is marked NEW.
          </p>
          <button className="btn primary" onClick={onOpenSwitcher}>
            Open app switcher
          </button>
        </div>
      </div>
    </div>
  );
}

function App() {
  // Route: { product: 'wfm' | 'fi', section: 'campaigns' | ..., view: 'list' | 'create' }
  const [route, setRoute] = React.useState({ product: "fi", section: "campaigns", view: "list" });
  const [switcherOpen, setSwitcherOpen] = React.useState(false);
  const [navMinimized, setNavMinimized] = React.useState(false);
  const [toast, setToast] = React.useState(null);

  React.useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(null), 2800);
    return () => clearTimeout(t);
  }, [toast]);

  const product = route.product === "fi" ? "Feedback Intelligence" : "Workforce Management";
  const productAccent = route.product === "fi" ? "fi" : "";

  let nav, content;
  if (route.product === "wfm") {
    nav = WFM_NAV;
    content = <WFMPlaceholder onOpenSwitcher={() => setSwitcherOpen(true)}/>;
  } else {
    nav = FI_NAV.map(n => {
      if (n.type === "group") {
        const children = (n.children || []).map(c => ({ ...c, active: c.key === route.section }));
        const anyActive = children.some(c => c.active);
        return { ...n, children, expanded: anyActive || n.expanded };
      }
      return { ...n, active: n.key === route.section };
    });
    if (route.section === "campaigns") {
      if (route.view === "create") {
        content = <CreateCampaign
          template={route.template || null}
          onCancel={() => setRoute({ ...route, view: "list" })}
          onSave={(c) => {
            setToast({ icon: "check", msg: c.status === "active" ? `Campaign "${c.name}" is now live.` : `Campaign "${c.name}" saved as draft.` });
            setRoute({ ...route, view: "list" });
          }}/>;
      } else if (route.view === "detail" && route.campaign) {
        content = <CampaignDetail
          campaign={route.campaign}
          onBack={() => setRoute({ ...route, view: "list", campaign: null })}
          onEdit={() => setRoute({ ...route, view: "create" })}/>;
      } else {
        content = <SurveyCampaignsGrid
          onCreate={() => setRoute({ ...route, view: "create" })}
          onOpen={(c) => setRoute({ ...route, view: "detail", campaign: c })}/>;
      }
    } else if (route.section === "ontology") {
      content = <VUScoreModel/>;
    } else if (route.section === "designs") {
      if (route.view === "create" || route.view === "edit") {
        content = <CreateSurveyDesign
          initial={route.view === "edit" ? route.design : null}
          onCancel={() => setRoute({ ...route, view: "list", design: null })}
          onSave={(d) => {
            setToast({ msg: `Survey template "${d.name}" saved.` });
            setRoute({ ...route, view: "list", design: null });
          }}/>;
      } else {
        content = <SurveyDesignsGrid
          onCreate={() => setRoute({ ...route, view: "create" })}
          onOpen={(d) => setRoute({ ...route, view: "edit", design: d })}/>;
      }
    } else {
      content = (
        <div className="pane">
          <div className="pane-head">
            <h1>{FI_NAV.find(n => n.key === route.section)?.label || ""}</h1>
          </div>
          <div style={{ padding: 32, color: "var(--lyra-slate-500)", font: "400 14px/22px Inter", textAlign: "center" }}>
            This area is part of Feedback Intelligence — wire-up coming after Survey Campaigns is reviewed.
          </div>
        </div>
      );
    }
  }

  return (
    <div className={`app ${route.product === "fi" ? "fi-shell" : ""} ${switcherOpen ? "open" : ""}${navMinimized ? " nav-minimized" : ""}`}>
      <Topbar
        product={product}
        productAccent={productAccent}
        onProductClick={() => setSwitcherOpen(!switcherOpen)}
        onAppSwitcherClick={() => setSwitcherOpen(!switcherOpen)}
      />
      <LeftNav items={nav}
        minimized={navMinimized}
        onToggleMinimized={() => setNavMinimized(m => !m)}
        onLeafClick={(leaf) => {
          if (leaf.key) setRoute({ product: "fi", section: leaf.key, view: "list" });
        }}/>
      <div className="main">{content}</div>

      {switcherOpen ? (
        <AppSwitcher
          currentProduct={route.product === "fi" ? "FI" : "WFM"}
          onClose={() => setSwitcherOpen(false)}
          onNavigate={(p) => {
            setSwitcherOpen(false);
            if (p === "fi") {
              setRoute({ product: "fi", section: "campaigns", view: "list" });
            } else {
              setRoute({ product: "wfm", section: "rta", view: "list" });
            }
          }}
        />
      ) : null}

      {toast ? (
        <div className="toast">
          <svg viewBox="0 0 24 24"><polyline points="4 13 10 19 20 5"/></svg>
          {toast.msg}
        </div>
      ) : null}
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App/>);
