// Keyed by scale shape, not by metric — any metric using a given scale (ASAT, CSAT, future
// metrics) shares the one config for that scale instead of each metric having its own.
export type QuestionTypeKey = 'scale5' | 'scale10' | 'verbatim'
export type ThemeChannel = 'digital'

export interface QuestionConfig {
  control: string
  scaleLabels: boolean
  lowLabel: string
  highLabel: string
  midLabels: string[]
  listPickerLabel: string
}

export function scalePoints(qType: QuestionTypeKey): number {
  if (qType === 'scale5') return 5
  if (qType === 'scale10') return 10
  return 0
}

export interface MessageConfig {
  mode: 'optout' | 'plain' | 'none'
  startLabel: string
  intro: string
  optLabel: string
  thanks: string
}

export interface Theme {
  id: string
  nm: string
  sys: boolean
  def: boolean
  ds: string
  // User-facing description shown in the Themes grid and on the theme page (max 200 chars, optional)
  description: string
  ch: ThemeChannel
  q: Record<QuestionTypeKey, QuestionConfig>
  msg: MessageConfig
  updatedOn?: string
  updatedBy?: string
  linkedPrograms?: string[]
}

export const CONTROL_OPTIONS: Record<ThemeChannel, { scale: string[]; verbatim: string[] }> = {
  digital: { scale: ['listpicker', 'quickreply'], verbatim: ['textarea'] },
}

const DEFAULT_CONTROLS: Record<ThemeChannel, { scale: string; verbatim: string }> = {
  digital: { scale: 'listpicker', verbatim: 'textarea' },
}

function makeQ(ch: ThemeChannel): Record<QuestionTypeKey, QuestionConfig> {
  const s = DEFAULT_CONTROLS[ch]
  return {
    scale5: {
      control: s.scale,
      scaleLabels: false,
      lowLabel: 'Very dissatisfied',
      highLabel: 'Very satisfied',
      midLabels: ['Dissatisfied', 'Neutral', 'Satisfied'],
      listPickerLabel: 'Rate your experience',
    },
    scale10: {
      control: s.scale,
      scaleLabels: false,
      lowLabel: 'Not at all likely',
      highLabel: 'Extremely likely',
      midLabels: ['', '', '', '', '', '', '', ''],
      listPickerLabel: 'Rate your experience',
    },
    verbatim: {
      control: s.verbatim,
      scaleLabels: false,
      lowLabel: '',
      highLabel: '',
      midLabels: [],
      listPickerLabel: '',
    },
  }
}

function makeMsg(): MessageConfig {
  return {
    mode: 'optout',
    startLabel: 'Get Started',
    intro: "Dear {contact_firstName}, We'd love to hear about your experience today. We have just a few quick questions, just two minutes. Thanks! What will your feedback tell us.",
    optLabel: 'Not Today',
    thanks: 'Thank you {contact_firstName} for providing your valuable feedback.',
  }
}

export const db: { lf: Record<ThemeChannel, Theme[]> } = {
  lf: {
    digital: [
      {
        id:  'lfd1',
        nm:  'Digital — system default',
        sys: true,
        def: true,
        ds:  "Default digital theme. Applied to any program that hasn't set a custom theme.",
        description: 'System default for digital programs. List picker for ratings, a text area for open answers, and an invitation with an opt-out button.',
        ch:  'digital',
        q:   makeQ('digital'),
        msg: makeMsg(),
        linkedPrograms: ['Billing Effort Score', 'Home service feedback survey', 'Tech support satisfaction survey', 'Product quality feedback survey', 'Fitness program satisfaction survey', 'Onboarding Feedback B2B'],
      },
      {
        id:  't3',
        nm:  'Digital - Theme for billing related survey',
        sys: false,
        def: false,
        ds:  'Quick reply control with scale labels on. Used by the Billing Support program.',
        description: 'Quick reply buttons with scale labels on the 1 to 5 scale question, and a short billing-specific invitation.',
        ch:  'digital',
        q: {
          scale5:   { control: 'quickreply', scaleLabels: true,  lowLabel: 'Very dissatisfied', highLabel: 'Very satisfied', midLabels: ['Dissatisfied', 'Neutral', 'Satisfied'], listPickerLabel: 'Rate your experience' },
          scale10:  { control: 'quickreply', scaleLabels: false, lowLabel: 'Not at all likely',  highLabel: 'Extremely likely', midLabels: ['', '', '', '', '', '', '', ''],        listPickerLabel: 'Rate your experience' },
          verbatim: { control: 'textarea',   scaleLabels: false, lowLabel: '',                  highLabel: '',               midLabels: [],                                        listPickerLabel: '' },
        },
        msg: {
          ...makeMsg(),
          intro: 'How was your billing support experience? Your feedback helps our team.',
        },
        updatedOn: 'Aug 11, 2026 10:55:06 AM',
        updatedBy: 'Maria',
        linkedPrograms: ['Billing Effort Score'],
      },
      {
        id:  't4',
        nm:  'Digital - Theme for retail survey',
        sys: false,
        def: false,
        ds:  'Quick reply control. Used by the Retail Feedback program.',
        description: '',
        ch:  'digital',
        q:   makeQ('digital'),
        msg: {
          ...makeMsg(),
          intro: 'How was your shopping experience with us today?',
        },
        updatedOn: 'Aug 12, 2026 10:55:06 AM',
        updatedBy: 'Dave',
        linkedPrograms: [],
      },
      {
        id:  't5',
        nm:  'Digital - Plain invitation, no opt-out',
        sys: false,
        def: false,
        ds:  'Plain invitation message, list picker ratings.',
        description: 'Plain invitation with no opt-out button, so customers go straight into the survey. List picker for all ratings.',
        ch:  'digital',
        q:   makeQ('digital'),
        msg: { ...makeMsg(), mode: 'plain' },
        updatedOn: 'Aug 14, 2026 09:12:40 AM',
        updatedBy: 'Jaden Smith',
        linkedPrograms: ['Tech support satisfaction survey'],
      },
      {
        id:  't6',
        nm:  'Digital - Labelled 1 to 5 scale question',
        sys: false,
        def: false,
        ds:  'Quick reply with labels on the 1 to 5 scale question.',
        description: 'Quick reply buttons with the full 5-point label set shown on the 1 to 5 scale question.',
        ch:  'digital',
        q: {
          ...makeQ('digital'),
          scale5: { control: 'quickreply', scaleLabels: true, lowLabel: 'Very dissatisfied', highLabel: 'Very satisfied', midLabels: ['Dissatisfied', 'Neutral', 'Satisfied'], listPickerLabel: 'Rate your experience' },
        },
        msg: makeMsg(),
        updatedOn: 'Aug 18, 2026 03:40:22 PM',
        updatedBy: 'Maria',
        linkedPrograms: [],
      },
      {
        id:  't7',
        nm:  'Digital - Theme for home services',
        sys: false,
        def: false,
        ds:  'Warm invitation copy for post-visit surveys.',
        description: '',
        ch:  'digital',
        q:   makeQ('digital'),
        msg: {
          ...makeMsg(),
          intro: 'Hi {contact_firstName}, thanks for having us over today. How did our visit go?',
        },
        updatedOn: 'Aug 20, 2026 11:05:51 AM',
        updatedBy: 'Dave',
        linkedPrograms: ['Home service feedback survey'],
      },
      {
        id:  't8',
        nm:  'Digital - Silent close, no thank-you',
        sys: false,
        def: false,
        ds:  'No invitation message, ends without a thank-you.',
        description: 'Skips the invitation and opens on the first question. Ends without a thank-you message, for very short pulse checks.',
        ch:  'digital',
        q:   makeQ('digital'),
        msg: { ...makeMsg(), mode: 'none', thanks: '' },
        updatedOn: 'Aug 22, 2026 04:18:09 PM',
        updatedBy: 'Jaden Smith',
        linkedPrograms: [],
      },
    ],
  },
}

export function getAllThemes(): Theme[] {
  return [...db.lf.digital]
}

export function getThemeById(id: string): Theme | undefined {
  return getAllThemes().find(t => t.id === id)
}

export function getControlOptions(ch: ThemeChannel, qType: QuestionTypeKey): string[] {
  return qType === 'verbatim' ? CONTROL_OPTIONS[ch].verbatim : CONTROL_OPTIONS[ch].scale
}

export function syncTheme(updated: Theme): void {
  const arr = db.lf[updated.ch]
  const idx = arr.findIndex(t => t.id === updated.id)
  if (idx !== -1) arr[idx] = { ...updated, updatedOn: nowStamp(), updatedBy: 'Jaden Smith' }
}

function nowStamp(): string {
  const now = new Date()
  const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']
  let h = now.getHours()
  const ampm = h >= 12 ? 'PM' : 'AM'
  h = h % 12 || 12
  return `${months[now.getMonth()]} ${now.getDate()}, ${now.getFullYear()} ${String(h).padStart(2,'0')}:${String(now.getMinutes()).padStart(2,'0')}:${String(now.getSeconds()).padStart(2,'0')} ${ampm}`
}

export function createTheme(nm: string, ch: ThemeChannel): Theme {
  const t: Theme = {
    id:  `t${Date.now()}`,
    nm:  sanitizeName(nm).slice(0, 50),
    sys: false,
    def: false,
    ds:  'Custom digital theme',
    description: '',
    ch,
    q:   makeQ(ch),
    msg: makeMsg(),
    updatedOn: nowStamp(),
    updatedBy: 'Jaden Smith',
  }
  db.lf[ch].push(t)
  return t
}

export function makeDraftTheme(ch: ThemeChannel): Theme {
  return {
    id: '',
    nm: '',
    sys: false,
    def: false,
    ds: 'Custom digital theme',
    description: '',
    ch,
    q: makeQ(ch),
    msg: makeMsg(),
  }
}

export function saveNewTheme(theme: Theme): Theme {
  const t: Theme = {
    ...theme,
    id: `t${Date.now()}`,
    nm: sanitizeName(theme.nm).trim().slice(0, 50),
    updatedOn: nowStamp(),
    updatedBy: 'Jaden Smith',
  }
  db.lf[theme.ch].push(t)
  return t
}

export function suggestDuplicateName(theme: Theme): string {
  const baseName = theme.sys ? 'Digital —' : theme.nm
  const existing = new Set(getAllThemes().map(t => t.nm.trim().toLowerCase()))
  let n = 1
  let candidate = `${baseName} (Copy ${n})`.slice(0, 50)
  while (existing.has(candidate.trim().toLowerCase())) {
    n += 1
    candidate = `${baseName} (Copy ${n})`.slice(0, 50)
  }
  return candidate
}

export function isThemeNameTaken(nm: string, excludeId?: string): boolean {
  const q = nm.trim().toLowerCase()
  return getAllThemes().some(t => t.id !== excludeId && t.nm.trim().toLowerCase() === q)
}

export function duplicateTheme(theme: Theme, name?: string): Theme {
  const nm = (name?.trim() || suggestDuplicateName(theme)).slice(0, 50)
  const copy: Theme = {
    ...(JSON.parse(JSON.stringify(theme)) as Theme),
    id:  `t${Date.now()}`,
    nm,
    sys: false,
    def: false,
    ds:  'Custom digital theme',
    // Keep a custom theme's description; the system default's text describes the default, so start blank
    description: theme.sys ? '' : theme.description,
    updatedOn: nowStamp(),
    updatedBy: 'Jaden Smith',
  }
  db.lf[theme.ch].push(copy)
  return copy
}

export function deleteTheme(theme: Theme): { ok: boolean; reason?: string } {
  if (theme.sys) return { ok: false, reason: 'System themes cannot be deleted.' }
  const arr = db.lf[theme.ch]
  if (arr.length <= 1) return { ok: false, reason: 'Cannot delete the only theme for this channel.' }
  const idx = arr.findIndex(t => t.id === theme.id)
  if (idx === -1) return { ok: false }
  arr.splice(idx, 1)
  if (theme.def && arr.length > 0) arr[0].def = true
  return { ok: true }
}

/* ─── Validation helpers ─── */

const RESTRICTED_RE = /[\\\/!+<>?#&,%"]/g

export function sanitizeName(v: string): string {
  return v.replace(RESTRICTED_RE, '')
}

export function hasRestrictedChars(v: string): boolean {
  return RESTRICTED_RE.test(v)
}

export interface ThemeValidationErrors {
  nm?: string
  listPickerLabel?: string
  startLabel?: string
  optLabel?: string
}

export function validateTheme(theme: Theme): ThemeValidationErrors {
  const errors: ThemeValidationErrors = {}
  if (!theme.nm.trim()) errors.nm = 'Required'
  const scaleTypes: QuestionTypeKey[] = ['scale5', 'scale10']
  if (scaleTypes.some(qt => theme.q[qt].control === 'listpicker')) {
    const hasEmpty = scaleTypes.some(
      qt => theme.q[qt].control === 'listpicker' && !theme.q[qt].listPickerLabel.trim()
    )
    if (hasEmpty) errors.listPickerLabel = 'Required'
  }
  if (!theme.msg.startLabel.trim()) errors.startLabel = 'Required'
  if (theme.msg.mode === 'optout' && !theme.msg.optLabel.trim()) errors.optLabel = 'Required'
  return errors
}

export function hasValidationErrors(errors: ThemeValidationErrors): boolean {
  return Object.keys(errors).length > 0
}
